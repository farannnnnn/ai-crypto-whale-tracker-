// Mock data for the cryptocurrency intelligence platform

// Whale Transactions
export const mockWhaleTransactions = [
  {
    type: 'in',
    coin: 'Bitcoin',
    amount: 12500000,
    wallet: '3FZbgi29cpjq2GjdwV8eyHuJJnkLtktZc5',
    exchange: 'Binance',
    timestamp: new Date(Date.now() - 15 * 60 * 1000), // 15 minutes ago
    riskScore: 25,
  },
  {
    type: 'out',
    coin: 'Ethereum',
    amount: 9800000,
    wallet: '0x8894e0a0c962cb723c1976a4421c95949be2d4e3',
    exchange: 'Unknown',
    timestamp: new Date(Date.now() - 47 * 60 * 1000), // 47 minutes ago
    riskScore: 78,
  },
  {
    type: 'in',
    coin: 'Solana',
    amount: 3250000,
    wallet: 'CEuGm3dKPBtUBdQmALU8i8UKAoXykYEJXAYEuNxBr4Vj',
    exchange: 'Coinbase',
    timestamp: new Date(Date.now() - 2.3 * 60 * 60 * 1000), // 2.3 hours ago
    riskScore: 15,
  },
  {
    type: 'out',
    coin: 'Bitcoin',
    amount: 8750000,
    wallet: 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh',
    exchange: 'Kraken',
    timestamp: new Date(Date.now() - 3.7 * 60 * 60 * 1000), // 3.7 hours ago
    riskScore: 42,
  },
  {
    type: 'in',
    coin: 'Ethereum',
    amount: 4250000,
    wallet: '0x1f9090aaE28b8a3dCeaDf281B0F12828e676c326',
    exchange: 'FTX',
    timestamp: new Date(Date.now() - 5.1 * 60 * 60 * 1000), // 5.1 hours ago
    riskScore: 60,
  },
];

// Trending Coins by Sentiment
export const mockTrendingCoins = [
  {
    name: 'Bitcoin',
    symbol: 'BTC',
    sentiment: 7.2,
    change: 2.4,
  },
  {
    name: 'Ethereum',
    symbol: 'ETH',
    sentiment: 5.8,
    change: 1.3,
  },
  {
    name: 'Solana',
    symbol: 'SOL',
    sentiment: 9.1,
    change: 8.7,
  },
  {
    name: 'Cardano',
    symbol: 'ADA',
    sentiment: -2.3,
    change: -3.1,
  },
  {
    name: 'Polygon',
    symbol: 'MATIC',
    sentiment: 4.5,
    change: 3.2,
  },
];

// Whale Wallets
export const mockWallets = [
  {
    address: '3FZbgi29cpjq2GjdwV8eyHuJJnkLtktZc5',
    balance: 134500000,
    change: 3.2,
    label: 'Binance Cold Wallet',
    riskScore: 12,
  },
  {
    address: '0x8894e0a0c962cb723c1976a4421c95949be2d4e3',
    balance: 89700000,
    change: -2.1,
    label: 'Unknown Entity',
    riskScore: 85,
  },
  {
    address: 'CEuGm3dKPBtUBdQmALU8i8UKAoXykYEJXAYEuNxBr4Vj',
    balance: 45200000,
    change: 12.5,
    label: 'Alameda Research',
    riskScore: 68,
  },
  {
    address: 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh',
    balance: 78300000,
    change: 5.7,
    label: 'Grayscale Bitcoin Trust',
    riskScore: 8,
  },
  {
    address: '0x1f9090aaE28b8a3dCeaDf281B0F12828e676c326',
    balance: 32100000,
    change: -8.3,
    label: 'Jump Trading',
    riskScore: 42,
  },
];