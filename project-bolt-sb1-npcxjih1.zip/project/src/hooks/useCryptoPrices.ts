import { useState, useEffect } from 'react';

interface CryptoPrice {
  price: number;
  change_24h: number;
}

interface PriceData {
  [key: string]: CryptoPrice;
}

export const useCryptoPrices = () => {
  const [prices, setPrices] = useState<PriceData>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchPrices = async () => {
      try {
        const response = await fetch(
          'https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,solana&vs_currencies=usd&include_24h_change=true'
        );
        
        if (!response.ok) {
          throw new Error('Failed to fetch prices');
        }

        const data = await response.json();
        
        setPrices({
          bitcoin: {
            price: data.bitcoin.usd,
            change_24h: data.bitcoin.usd_24h_change,
          },
          ethereum: {
            price: data.ethereum.usd,
            change_24h: data.ethereum.usd_24h_change,
          },
          solana: {
            price: data.solana.usd,
            change_24h: data.solana.usd_24h_change,
          },
        });
        setLoading(false);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch prices');
        setLoading(false);
      }
    };

    fetchPrices();
    const interval = setInterval(fetchPrices, 30000); // Update every 30 seconds

    return () => clearInterval(interval);
  }, []);

  return { prices, loading, error };
};