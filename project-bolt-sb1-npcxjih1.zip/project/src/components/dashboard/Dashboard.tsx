import React from 'react';
import WhaleTracker from './WhaleTracker';
import AiTrends from './AiTrends';
import WalletInsights from './WalletInsights';
import AiAssistant from './AiAssistant';
import StatsOverview from './StatsOverview';
import { ActiveView } from '../layout/Layout';

interface DashboardProps {
  activeView: ActiveView;
}

const Dashboard: React.FC<DashboardProps> = ({ activeView }) => {
  const renderContent = () => {
    switch (activeView) {
      case 'whale-tracker':
        return <WhaleTracker />;
      case 'ai-trends':
        return <AiTrends />;
      case 'wallet-insights':
        return <WalletInsights />;
      case 'ai-assistant':
        return <AiAssistant />;
      case 'settings':
        return (
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Settings</h2>
            <p className="text-gray-600 dark:text-gray-400">Settings page coming soon...</p>
          </div>
        );
      case 'help':
        return (
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Help Center</h2>
            <p className="text-gray-600 dark:text-gray-400">Help documentation coming soon...</p>
          </div>
        );
      default:
        return (
          <div className="space-y-6">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
              Cryptocurrency Intelligence
            </h1>
            <StatsOverview />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <WhaleTracker />
              <AiTrends />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-2">
                <WalletInsights />
              </div>
              <div>
                <AiAssistant />
              </div>
            </div>
          </div>
        );
    }
  };

  return renderContent();
};

export default Dashboard;