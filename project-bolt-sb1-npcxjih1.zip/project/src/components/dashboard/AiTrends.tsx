import React, { useState } from 'react';
import { BrainCircuit, ArrowUp, ArrowDown, Twitter, MessageSquare } from 'lucide-react';
import { mockTrendingCoins } from '../../data/mockData';

const AiTrends: React.FC = () => {
  const [timeframe, setTimeframe] = useState<string>('24h');

  const timeframes = [
    { id: '1h', label: '1H' },
    { id: '24h', label: '24H' },
    { id: '7d', label: '7D' },
    { id: '30d', label: '30D' },
  ];

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm overflow-hidden">
      <div className="p-4 sm:p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <BrainCircuit size={20} className="text-blue-500 dark:text-blue-400" />
            <h2 className="text-lg font-bold text-gray-900 dark:text-white">AI Trends</h2>
          </div>
          <div className="flex space-x-2">
            {timeframes.map((tf) => (
              <button
                key={tf.id}
                onClick={() => setTimeframe(tf.id)}
                className={`px-2 py-1 text-xs font-medium rounded 
                ${timeframe === tf.id 
                  ? 'bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400' 
                  : 'text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700'}`}
              >
                {tf.label}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
            <div className="flex items-start">
              <div className="flex-shrink-0 mr-3">
                <div className="bg-blue-100 dark:bg-blue-800 p-2 rounded-lg">
                  <BrainCircuit size={20} className="text-blue-600 dark:text-blue-400" />
                </div>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-900 dark:text-white">AI Confidence Score</h3>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                  Our AI models have a current market direction confidence of <span className="font-medium text-blue-600 dark:text-blue-400">89%</span> based on on-chain metrics, social sentiment, and whale behavior analysis.
                </p>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-sm font-medium text-gray-900 dark:text-white mb-3">Trending by Sentiment</h3>
            <ul className="space-y-2">
              {mockTrendingCoins.map((coin, i) => (
                <li key={i} className="flex items-center justify-between p-3 rounded-lg bg-gray-50 dark:bg-gray-750 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                  <div className="flex items-center space-x-3">
                    <span className="font-medium text-gray-900 dark:text-white">{i + 1}.</span>
                    <span className="font-medium text-gray-900 dark:text-white">{coin.name}</span>
                    <span className="text-gray-500 dark:text-gray-400 text-sm">{coin.symbol}</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="flex items-center">
                      <div className="flex items-center space-x-1 text-xs">
                        <Twitter size={12} className="text-blue-400" />
                        <span className={coin.sentiment > 0 ? 'text-green-500' : 'text-red-500'}>
                          {coin.sentiment > 0 ? '+' : ''}{coin.sentiment}%
                        </span>
                      </div>
                    </div>
                    <div className={`flex items-center ${
                      coin.change > 0 
                        ? 'text-green-500' 
                        : 'text-red-500'
                    }`}>
                      {coin.change > 0 
                        ? <ArrowUp size={16} /> 
                        : <ArrowDown size={16} />
                      }
                      <span className="text-sm font-medium ml-1">{Math.abs(coin.change)}%</span>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </div>

          <div className="pt-2">
            <h3 className="text-sm font-medium text-gray-900 dark:text-white mb-2">Latest Insights</h3>
            <div className="space-y-2">
              <div className="p-3 rounded-lg bg-gray-50 dark:bg-gray-750">
                <div className="flex items-start">
                  <MessageSquare size={16} className="text-blue-500 mt-0.5 mr-2 flex-shrink-0" />
                  <p className="text-xs text-gray-700 dark:text-gray-300">
                    <span className="font-semibold">AI Analysis:</span> Bitcoin whale accumulation has increased by 15% in the last 24 hours, historically a bullish indicator.
                  </p>
                </div>
              </div>
              <div className="p-3 rounded-lg bg-gray-50 dark:bg-gray-750">
                <div className="flex items-start">
                  <MessageSquare size={16} className="text-blue-500 mt-0.5 mr-2 flex-shrink-0" />
                  <p className="text-xs text-gray-700 dark:text-gray-300">
                    <span className="font-semibold">AI Analysis:</span> Ethereum's social sentiment shows growing interest in upcoming protocol changes. Monitoring closely.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AiTrends;