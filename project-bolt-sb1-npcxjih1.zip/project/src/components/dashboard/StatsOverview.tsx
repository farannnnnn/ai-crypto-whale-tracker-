import React from 'react';
import { TrendingUp, TrendingDown, AlertTriangle, DollarSign } from 'lucide-react';
import { formatCurrency, formatNumber } from '../../utils/formatters';
import { useCryptoPrices } from '../../hooks/useCryptoPrices';

interface StatCardProps {
  title: string;
  value: string;
  change: string;
  isPositive: boolean;
  icon: React.ReactNode;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, change, isPositive, icon }) => {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4 transition-all duration-300 hover:shadow-md">
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <p className="text-sm font-medium text-gray-500 dark:text-gray-400">{title}</p>
          <p className="text-xl font-bold text-gray-900 dark:text-white">{value}</p>
        </div>
        <div className={`p-3 rounded-lg ${isPositive ? 'bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400' : 'bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400'}`}>
          {icon}
        </div>
      </div>
      <div className="mt-2 flex items-center">
        <span className={`text-sm font-medium ${isPositive ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
          {isPositive ? '+' : ''}{change}
        </span>
        <span className="text-gray-500 dark:text-gray-400 text-sm ml-1">24h change</span>
      </div>
    </div>
  );
};

const StatsOverview: React.FC = () => {
  const { prices, loading, error } = useCryptoPrices();

  if (loading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4 animate-pulse">
            <div className="h-16 bg-gray-200 dark:bg-gray-700 rounded"></div>
          </div>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 dark:bg-red-900/20 p-4 rounded-xl">
        <p className="text-red-600 dark:text-red-400">Failed to load cryptocurrency prices</p>
      </div>
    );
  }

  const stats = [
    {
      title: 'Bitcoin Price',
      value: formatCurrency(prices.bitcoin?.price || 0),
      change: `${prices.bitcoin?.change_24h?.toFixed(2) || '0.00'}%`,
      isPositive: (prices.bitcoin?.change_24h || 0) > 0,
      icon: <DollarSign size={20} />,
    },
    {
      title: 'Ethereum Price',
      value: formatCurrency(prices.ethereum?.price || 0),
      change: `${prices.ethereum?.change_24h?.toFixed(2) || '0.00'}%`,
      isPositive: (prices.ethereum?.change_24h || 0) > 0,
      icon: <DollarSign size={20} />,
    },
    {
      title: 'Solana Price',
      value: formatCurrency(prices.solana?.price || 0),
      change: `${prices.solana?.change_24h?.toFixed(2) || '0.00'}%`,
      isPositive: (prices.solana?.change_24h || 0) > 0,
      icon: <DollarSign size={20} />,
    },
    {
      title: 'Market Sentiment',
      value: 'Bullish',
      change: '5.8%',
      isPositive: true,
      icon: <TrendingUp size={20} />,
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat, index) => (
        <StatCard key={index} {...stat} />
      ))}
    </div>
  );
};

export default StatsOverview;