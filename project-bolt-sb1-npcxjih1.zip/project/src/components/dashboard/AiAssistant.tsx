import React, { useState, useRef, useEffect } from 'react';
import { Bot, Send, User } from 'lucide-react';

interface Message {
  id: number;
  content: string;
  sender: 'user' | 'assistant';
  timestamp: Date;
}

const AiAssistant: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      content: "Hello! I'm your AI crypto assistant. How can I help you understand the market today?",
      sender: 'assistant',
      timestamp: new Date(),
    },
  ]);
  
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: messages.length + 1,
      content: input,
      sender: 'user',
      timestamp: new Date(),
    };
    
    setMessages((prev) => [...prev, userMessage]);
    setInput('');

    // Simulate AI response
    setTimeout(() => {
      let response = '';
      
      if (input.toLowerCase().includes('bitcoin') || input.toLowerCase().includes('btc')) {
        response = "Bitcoin is currently in a bullish trend with strong on-chain metrics. Whale wallets have been accumulating over the past 72 hours, which historically signals potential upward movement.";
      } else if (input.toLowerCase().includes('ethereum') || input.toLowerCase().includes('eth')) {
        response = "Ethereum is showing mixed signals. While development activity remains strong, some large wallets have been distributing tokens. Market sentiment is neutral with a slight bullish bias.";
      } else if (input.toLowerCase().includes('risk') || input.toLowerCase().includes('safe')) {
        response = "Based on current market conditions, risk levels are moderate. I recommend diversifying your portfolio and not allocating more than 5% to any single altcoin at this time.";
      } else if (input.toLowerCase().includes('whales') || input.toLowerCase().includes('whale')) {
        response = "In the last 24 hours, whale activity has increased by 23%. Several large Bitcoin wallets have moved funds from exchanges to cold storage, typically a bullish signal indicating less selling pressure.";
      } else {
        response = "I've analyzed the market data and current sentiment appears cautiously optimistic. On-chain metrics show accumulation patterns among long-term holders, while social sentiment is trending positive for major cryptocurrencies.";
      }
      
      const aiMessage: Message = {
        id: messages.length + 2,
        content: response,
        sender: 'assistant',
        timestamp: new Date(),
      };
      
      setMessages((prev) => [...prev, aiMessage]);
    }, 1000);
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm overflow-hidden h-[500px] flex flex-col">
      <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex items-center space-x-2">
        <Bot size={20} className="text-blue-500 dark:text-blue-400" />
        <h2 className="text-lg font-bold text-gray-900 dark:text-white">AI Assistant</h2>
      </div>
      
      <div className="flex-1 overflow-auto p-4">
        <div className="space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                  message.sender === 'user'
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white'
                }`}
              >
                <div className="flex items-center space-x-2 mb-1">
                  {message.sender === 'assistant' ? (
                    <Bot size={16} className="text-blue-500 dark:text-blue-400" />
                  ) : (
                    <User size={16} className="text-white" />
                  )}
                  <span className="text-xs font-medium">
                    {message.sender === 'user' ? 'You' : 'AI Assistant'}
                  </span>
                </div>
                <p className="text-sm">{message.content}</p>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </div>
      
      <form onSubmit={handleSend} className="border-t border-gray-200 dark:border-gray-700 p-4">
        <div className="flex space-x-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about market trends, wallet activity, or risk assessment..."
            className="flex-1 border border-gray-300 dark:border-gray-600 rounded-lg px-4 py-2 text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <button
            type="submit"
            disabled={!input.trim()}
            className={`p-2 rounded-lg ${
              !input.trim()
                ? 'bg-gray-200 dark:bg-gray-700 text-gray-400 dark:text-gray-500 cursor-not-allowed'
                : 'bg-blue-500 text-white hover:bg-blue-600'
            }`}
          >
            <Send size={18} />
          </button>
        </div>
      </form>
    </div>
  );
};

export default AiAssistant;