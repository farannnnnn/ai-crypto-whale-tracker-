import React, { useState } from 'react';
import Header from './Header';
import Sidebar from './Sidebar';
import { useTheme } from '../../context/ThemeContext';

interface LayoutProps {
  children: React.ReactNode;
}

export type ActiveView = 'dashboard' | 'whale-tracker' | 'ai-trends' | 'wallet-insights' | 'ai-assistant' | 'settings' | 'help';

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const { theme } = useTheme();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activeView, setActiveView] = useState<ActiveView>('dashboard');

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  return (
    <div className={`min-h-screen flex flex-col ${theme === 'dark' ? 'dark' : ''}`}>
      <Header toggleSidebar={toggleSidebar} />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar isOpen={sidebarOpen} activeView={activeView} onViewChange={setActiveView} />
        <main className={`flex-1 overflow-auto transition-all duration-300 ease-in-out p-4 md:p-6 dark:bg-gray-900 bg-gray-100`}>
          {React.Children.map(children, child => {
            if (React.isValidElement(child)) {
              return React.cloneElement(child, { activeView });
            }
            return child;
          })}
        </main>
      </div>
    </div>
  );
};

export default Layout