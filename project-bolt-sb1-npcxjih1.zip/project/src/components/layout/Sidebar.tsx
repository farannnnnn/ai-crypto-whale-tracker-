import React from 'react';
import { BarChart3, Scale as Whale, BrainCircuit, Wallet, Bot, Settings, HelpCircle } from 'lucide-react';
import { ActiveView } from './Layout';

interface SidebarProps {
  isOpen: boolean;
  activeView: ActiveView;
  onViewChange: (view: ActiveView) => void;
}

interface NavItem {
  id: ActiveView;
  icon: React.ReactNode;
  label: string;
}

const navItems: NavItem[] = [
  { id: 'dashboard', icon: <BarChart3 size={20} />, label: 'Dashboard' },
  { id: 'whale-tracker', icon: <Whale size={20} />, label: 'Whale Tracker' },
  { id: 'ai-trends', icon: <BrainCircuit size={20} />, label: 'AI Trends' },
  { id: 'wallet-insights', icon: <Wallet size={20} />, label: 'Wallet Insights' },
  { id: 'ai-assistant', icon: <Bot size={20} />, label: 'AI Assistant' },
];

const bottomNavItems: NavItem[] = [
  { id: 'settings', icon: <Settings size={20} />, label: 'Settings' },
  { id: 'help', icon: <HelpCircle size={20} />, label: 'Help' },
];

const Sidebar: React.FC<SidebarProps> = ({ isOpen, activeView, onViewChange }) => {
  return (
    <aside
      className={`fixed inset-y-0 left-0 z-20 md:relative transform transition-all duration-300 ease-in-out 
      ${isOpen ? 'translate-x-0' : '-translate-x-full'} 
      md:translate-x-0 md:w-64 flex-shrink-0 w-64 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 shadow-sm`}
    >
      <div className="h-full flex flex-col justify-between overflow-y-auto">
        <div className="space-y-1 px-2 pt-20 md:pt-4">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onViewChange(item.id)}
              className={`w-full flex items-center px-3 py-2.5 rounded-lg text-sm font-medium 
              ${item.id === activeView
                ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400' 
                : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700/50'}`}
            >
              <span className="mr-3">{item.icon}</span>
              <span>{item.label}</span>
            </button>
          ))}
        </div>
        <div className="p-2">
          {bottomNavItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onViewChange(item.id)}
              className={`w-full flex items-center px-3 py-2.5 rounded-lg text-sm font-medium 
              ${item.id === activeView
                ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400' 
                : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700/50'}`}
            >
              <span className="mr-3">{item.icon}</span>
              <span>{item.label}</span>
            </button>
          ))}
        </div>
      </div>
    </aside>
  );
};

export default Sidebar